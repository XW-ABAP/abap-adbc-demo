*&---------------------------------------------------------------------*
*& Report ZFIR075
*&---------------------------------------------------------------------*
*&
*&---------------------------------------------------------------------*
REPORT zfir075.

DATA:gt_itab TYPE TABLE OF idcn_formlines.
DATA:object_tab TYPE TABLE OF idcn_formlines WITH HEADER LINE.
DATA: fi016_fr TYPE TABLE OF idcn_formlines WITH HEADER LINE.
DATA: lt_xml_interface TYPE  STANDARD TABLE OF j_3rf_form4_interface.
DATA: lt_formlines_b TYPE idcn_t_formlines,
      lt_formlines_i TYPE idcn_t_formlines.
DATA: git_outtab LIKE TABLE OF object_tab  .
FIELD-SYMBOLS: <git_outtab> LIKE git_outtab .
DATA:go_db         TYPE REF TO cl_sql_connection,
     go_sqlerr_ref TYPE REF TO cx_sql_exception,
     go_sqlerr_inv TYPE REF TO cx_parameter_invalid.

DATA:gc_tablename TYPE tabname.


DATA: BEGIN OF gt_outtab3 OCCURS 0,
        text           TYPE  j_3rff4fig_descript,
        strow          TYPE  j_3rff4row,
        amount_total   TYPE j_3rff4amount_total,
        amount_prev    TYPE  j_3rff4amount_prev,
        drilldown1     TYPE icon_c,
        drilldown2     TYPE icon_c,
        drilldown3     TYPE icon_c,
        adjustment     TYPE icon_c,
        "<!--condition value
        cellcolor      TYPE lvc_t_scol,
        "-->
*       Insert by note 1839352
        adjustment_cmp TYPE icon_c,
*       End of insert by note 1839352
      END OF gt_outtab3.

DATA:gt_itab3 LIKE TABLE OF gt_outtab3.
DATA:gt_outtab2 LIKE TABLE OF gt_outtab3.
DATA:object_tab3 LIKE TABLE OF  gt_outtab3 WITH HEADER LINE.
DATA: fi016_fr3 LIKE TABLE OF  gt_outtab3 WITH HEADER LINE.

DATA: git_outtab3 LIKE TABLE OF object_tab3  .
FIELD-SYMBOLS: <git_outtab3> LIKE git_outtab3 .




DATA BEGIN OF gt_output_list OCCURS 0.
DATA:  bukrs          LIKE bseg-bukrs.  "Due to PDF processing the structure should begin with bukrs
       INCLUDE STRUCTURE j_3rf_form4_alv.
DATA: gsber          LIKE bseg-gsber,
       hide_strow     LIKE j_3rf_form4_alv-strow,
       chapt          LIKE j_3rff4data-chapt,
       header         TYPE c,
       dec_total      TYPE aflex17d2o22n, "dmbtr,  AFLE type summ9
       dec_prev_total TYPE aflex17d2o22n, "dmbtr,   AFLE type summ9
       END OF gt_output_list,
       BEGIN OF gt_index OCCURS 0,
         bukrs    LIKE bseg-bukrs,
         gsber    LIKE bseg-gsber,
         tabname  TYPE slis_tabname,
         tabindex LIKE sy-index,
         strow    LIKE j_3rff4data-strow,
         chapt    LIKE j_3rff4data-chapt,
       END OF gt_index.




"FIELD-SYMBOLS: <fs>.
*声明alv相关变量
TYPE-POOLS:sils.   "引入slis 包 定义 使用专门alv
DATA:lt_fieldcat TYPE slis_t_fieldcat_alv,   "存储fieldcat 内表
     ls_fieldcat TYPE slis_fieldcat_alv,      "定义使用工作区
     ls_layout   TYPE slis_layout_alv.       "ALV格式控制的结构体
DATA:lt_event TYPE slis_t_event  ,  " 事件的内表
     ls_event TYPE slis_alv_event.  "事件的工作区
DATA:pgm  LIKE  sy-repid.
DATA lt_sort TYPE slis_t_sortinfo_alv .
DATA wa_sort TYPE slis_sortinfo_alv.
DATA ls_setting TYPE lvc_s_glay.
DATA: lv_colpos TYPE int2 .
DATA: lr_grid TYPE REF TO cl_gui_alv_grid.
DATA: lt_rows TYPE lvc_t_row WITH HEADER LINE.
DATA:
  filetab TYPE filetable WITH HEADER LINE,
  rc      TYPE i,
  g_file  TYPE rlgrap-filename,
  itab    TYPE TABLE OF alsmex_tabline WITH HEADER LINE.
DATA go_data TYPE REF TO data.


TYPES: BEGIN OF ty_data,
         ryear  TYPE faglflext-ryear,
         racct  TYPE faglflext-racct,
         rbukrs TYPE faglflext-rbukrs,
         rcntr  TYPE faglflext-rcntr,
         rfarea TYPE faglflext-rfarea,
         hslvt  TYPE faglflext-hslvt,
         hsl01  TYPE faglflext-hsl01,
         hsl02  TYPE faglflext-hsl02,
         hsl03  TYPE faglflext-hsl03,
         hsl04  TYPE faglflext-hsl04,
         hsl05  TYPE faglflext-hsl05,
         hsl06  TYPE faglflext-hsl06,
         hsl07  TYPE faglflext-hsl07,
         hsl08  TYPE faglflext-hsl08,
         hsl09  TYPE faglflext-hsl09,
         hsl10  TYPE faglflext-hsl10,
         hsl11  TYPE faglflext-hsl11,
         hsl12  TYPE faglflext-hsl12,
         txt50  TYPE skat-txt50,
         ltext  TYPE cskt-ltext,
         " fkbtx  TYPE tfkb-fkbtx,
         fkbtx  TYPE string,

         cjbm   TYPE zzorg,
         cjbmms TYPE zzorg_t,
       END OF ty_data.

DATA: lt_faglflext1 TYPE TABLE OF ty_data ."导入时alv内表
DATA: ls_faglflext1 TYPE ty_data.
DATA: lt_faglflext2 TYPE TABLE OF ty_data ."导入时alv内表
DATA: ls_faglflext2 TYPE ty_data.



SELECTION-SCREEN BEGIN OF BLOCK b2 WITH FRAME TITLE TEXT-002.
  PARAMETERS but1 RADIOBUTTON GROUP  rd USER-COMMAND u1 DEFAULT 'X'.
  PARAMETERS but2 RADIOBUTTON GROUP  rd.
  PARAMETERS but3 RADIOBUTTON GROUP  rd.
  PARAMETERS but4 RADIOBUTTON GROUP  rd.
*  PARAMETERS but5 RADIOBUTTON GROUP  rd.
SELECTION-SCREEN END OF BLOCK b2.

SELECTION-SCREEN BEGIN OF BLOCK b1 WITH FRAME TITLE TEXT-001.
  PARAMETERS:p_year TYPE bkpf-gjahr  DEFAULT sy-datum(4) MODIF ID m2.
  PARAMETERS:p_month TYPE rfsdo-bilabmon DEFAULT sy-datum+4(2) MODIF ID m2.
SELECTION-SCREEN END OF BLOCK b1.

AT SELECTION-SCREEN OUTPUT.
  CASE 'X'.
    WHEN but4.
      LOOP AT SCREEN.
        IF screen-group1 = 'M2' .
          screen-active = '0'.
        ENDIF.
        MODIFY SCREEN.
      ENDLOOP.
    WHEN but1 OR but2 OR but3.
      LOOP AT SCREEN.
        IF screen-group1 = 'M2' .
          screen-active = '1'.
        ENDIF.
        MODIFY SCREEN.
      ENDLOOP.
  ENDCASE.


START-OF-SELECTION.
  CASE 'X'.
    WHEN but1.
      PERFORM get_data1.
      PERFORM frm_save1.
    WHEN but2.
      PERFORM get_data2.
      PERFORM frm_save2.
    WHEN but3.
      PERFORM get_data3.
      PERFORM frm_save3.
    WHEN but4.
      PERFORM get_data4.
      PERFORM frm_save4.
  ENDCASE.


*START-OF-SELECTION.
**  IF sy-batch = ''."前台
**    MESSAGE '请后台执行' TYPE 'I'.
**  ELSE.
*    PERFORM get_data1.
*    PERFORM frm_save1.
*    PERFORM get_data2.
*    PERFORM frm_save2.
*    PERFORM get_data3.
*    PERFORM frm_save3.
*    PERFORM get_data4.
*    PERFORM frm_save4.
* " ENDIF.





FORM get_data1.


  " 设定SALV运行模式
  cl_salv_bs_runtime_info=>set(
    EXPORTING
      display  = abap_false  "不显示
      metadata = abap_false
      data     = abap_true
  ).


*
  SUBMIT rfidcn_bsais
  WITH sd_bukrs-low = '1100'
  WITH fsckey = '1100'
  WITH versn = '1100'
  "WITH langu = 'ZH'
*  WITH bilbjahr = '2025'
*  WITH r-monate-low = '5'
*  WITH cilvjahr = '2025'
*  WITH c-monate-low = '5'

  WITH bilbjahr = p_year
  WITH r-monate-low = p_month
  WITH cilvjahr = p_year
  WITH c-monate-low = p_month

  WITH sd_rldnr-low = '0L'
  WITH bilaskal = '0.2'
  WITH kurst = 'M'

*  WITH o_direct = 'X'"change by jinnyding 20250620
*  WITH bilagrid = space
*  WITH p_excel = space
*  WITH p_adobe = space
  AND RETURN.
*  TRY.
*      "取得运行数据
*      cl_salv_bs_runtime_info=>get_data_ref(
*            IMPORTING
*              r_data = go_data
*      ).
**   数据赋值
*      ASSIGN  go_data->* TO <git_outtab>.
*
**     LOOP AT <git_outtab> ASSIGNING FIELD-SYMBOL(<fs1>).
**        APPEND <fs1> TO gt_itab .
**      ENDLOOP.
*
*    CATCH cx_salv_bs_sc_runtime_info.
*
*
*  ENDTRY.
*  CALL METHOD cl_salv_bs_runtime_info=>clear_all.
*
*   LOOP AT <git_outtab> ASSIGNING FIELD-SYMBOL(<fs1>).
*        APPEND <fs1> TO gt_itab .
*      ENDLOOP.


  IMPORT mt_formlines_b TO lt_formlines_b FROM MEMORY ID 'ZMT_B'.
  " IMPORT mt_formlines_i TO lt_formlines_i FROM MEMORY ID 'ZMT_I'.



ENDFORM.







FORM frm_save1 .


  TYPES: BEGIN OF ty_db,
           id TYPE string,
         END OF ty_db.

  DATA:lt_db TYPE TABLE OF ty_db.
  " DATA:lt_db TYPE TABLE OF zfis016.
  gc_tablename = 'ZFIR075A'.
  DATA go_data2 TYPE REF TO data.


*  DATA(lv_year) = '2025'.
*  DATA(lv_month) = '5'.

  DATA(lv_year) = p_year.
  DATA(lv_month) = p_month.

  CLEAR:lt_db[].
  "先获取对方数据
  TRY.
      go_db = cl_sql_connection=>get_connection( 'RPDB' ).

      " create the query string
      DATA(l_stmt) = |SELECT  ID  FROM { gc_tablename }  |.
      " create a statement object
      DATA(l_stmt_ref) = go_db->create_statement( tab_name_for_trace = gc_tablename ).
      DATA(l_res_ref) = l_stmt_ref->execute_query( l_stmt ).

      GET REFERENCE OF lt_db INTO go_data2.
      " set output table
      l_res_ref->set_param_table( go_data2 ).

      " get the complete result set
      DATA(l_row_cnt) = l_res_ref->next_package( ).

    CATCH cx_sql_exception INTO go_sqlerr_ref.
      MESSAGE go_sqlerr_ref->sql_message TYPE 'E'.
  ENDTRY.

  IF lt_db[] IS NOT INITIAL."删除数据
    TRY.
        l_stmt  = |DELETE FROM { gc_tablename }  WHERE YEAR =  '{ lv_year } ' AND MONTH =  '{ lv_month } ' |  .
        " create a statement object
        l_stmt_ref = go_db->create_statement( tab_name_for_trace = gc_tablename ).
        DATA(l_res_ref2) = l_stmt_ref->execute_update( l_stmt ).
      CATCH cx_sql_exception INTO go_sqlerr_ref.
        " <fs_data>-msg = <fs_data>-msg && go_sqlerr_ref->sql_message.
        MESSAGE go_sqlerr_ref->sql_message TYPE 'E'.
      CATCH cx_parameter_invalid INTO go_sqlerr_inv.
        "<fs_data>-msg = <fs_data>-msg && go_sqlerr_inv->get_text( ).
        MESSAGE go_sqlerr_inv->get_text( ) TYPE 'E'.
    ENDTRY.
  ENDIF.


  LOOP AT lt_formlines_b ASSIGNING FIELD-SYMBOL(<fs_data>).
    "LOOP AT gt_itab ASSIGNING FIELD-SYMBOL(<fs_data>).

    "插入数据
    TRY.
        DATA: lv_id(32) TYPE c.
        lv_id = cl_uuid_factory=>create_system_uuid( )->create_uuid_c32( ).
        "  create the query string

        l_stmt = |INSERT INTO { gc_tablename } VALUES(| &&
                       |'{ lv_id }',| &&
                       |'{ lv_year }',| &&
                       |'{ lv_month }',| &&
                       |'{ <fs_data>-linenr }',| &&  "表格部分
                       |'{ <fs_data>-linesec }',| &&   "表格部分
                       |'{ <fs_data>-linelev }',| &&  "抵销编号
                       |'{ <fs_data>-linetype }',| &&  "表格行类型
                       |'{ <fs_data>-linetext }',| &&  "行描述
                       |'{ <fs_data>-linenrext }',| &&  "顺序编号
                       |'{ <fs_data>-ergsl }',| &&  "财务报表项目
                       |'{ <fs_data>-bsum }',| &&  " 货币金额
                       |'{ <fs_data>-vsum }',| &&  "比较金额
                       |'{ <fs_data>-saldo }',| &&  "差额
                       |'{ <fs_data>-waers }')|.  "货币码

        "     |TO_DATE('{ <fs_data>-gltrp }','YYYYMMDD'),| &&
        " create a statement object
        l_stmt_ref = go_db->create_statement( tab_name_for_trace = gc_tablename ).
        DATA(l_res_ref3) = l_stmt_ref->execute_update( l_stmt ).
      CATCH cx_sql_exception INTO go_sqlerr_ref.
        " <fs_data>-msg = <fs_data>-msg && go_sqlerr_ref->sql_message.
        MESSAGE go_sqlerr_ref->sql_message TYPE 'E'.
      CATCH cx_parameter_invalid INTO go_sqlerr_inv.
        "<fs_data>-msg = <fs_data>-msg && go_sqlerr_inv->get_text( ).
        MESSAGE go_sqlerr_inv->get_text( ) TYPE 'E'.
    ENDTRY.
  ENDLOOP.
  MESSAGE 'ZFIR075A 资产负债表数据同步完毕' TYPE 'S'.


ENDFORM.



FORM get_data2.


  RANGES:r_monate FOR rfsdo-bilabmon.
  r_monate-sign = 'I'.
  r_monate-option = 'BT'.
  r_monate-low = '1'.
  r_monate-high = p_month.
  APPEND r_monate.



  " 设定SALV运行模式
  cl_salv_bs_runtime_info=>set(
    EXPORTING
      display  = abap_false  "不显示
      metadata = abap_false
      data     = abap_true
  ).



  SUBMIT rfidcn_bsais
  WITH sd_bukrs-low = '1100'
  WITH fsckey = '1100'
  WITH versn = '1100'
  WITH bilbjahr = p_year
  WITH r-monate-low = p_month
  WITH cilvjahr = p_year
  "WITH c-monate-low = p_month
  WITH c-monate-low IN r_monate
  WITH sd_rldnr-low = '0L'
  WITH bilaskal = '0.2'
  WITH kurst = 'M'
*  WITH o_direct = 'X'"change by jinnyding 20250620
*   WITH bilagrid = space
*  WITH p_excel = space
*  WITH p_adobe = space
  AND RETURN.

  "IMPORT MT_FORMLINES_B TO LT_FORMLINES_B FROM MEMORY ID 'ZMT_B'.
  IMPORT mt_formlines_i TO lt_formlines_i FROM MEMORY ID 'ZMT_I'.



ENDFORM.





FORM frm_save2 .


  TYPES: BEGIN OF ty_db,
           id TYPE string,
         END OF ty_db.

  DATA:lt_db TYPE TABLE OF ty_db.
  " DATA:lt_db TYPE TABLE OF zfis016.
  gc_tablename = 'ZFIR075B'.
  DATA go_data2 TYPE REF TO data.


  DATA(lv_year) = p_year.
  DATA(lv_month) = p_month.

  CLEAR:lt_db[].
  "先获取对方数据
  TRY.
      go_db = cl_sql_connection=>get_connection( 'RPDB' ).

      " create the query string
      DATA(l_stmt) = |SELECT  ID  FROM { gc_tablename }  |.
      " create a statement object
      DATA(l_stmt_ref) = go_db->create_statement( tab_name_for_trace = gc_tablename ).
      DATA(l_res_ref) = l_stmt_ref->execute_query( l_stmt ).

      GET REFERENCE OF lt_db INTO go_data2.
      " set output table
      l_res_ref->set_param_table( go_data2 ).

      " get the complete result set
      DATA(l_row_cnt) = l_res_ref->next_package( ).

    CATCH cx_sql_exception INTO go_sqlerr_ref.
      MESSAGE go_sqlerr_ref->sql_message TYPE 'E'.
  ENDTRY.

  IF lt_db[] IS NOT INITIAL."删除数据
    TRY.
        l_stmt  = |DELETE FROM { gc_tablename }  WHERE YEAR =  '{ lv_year } ' AND MONTH =  '{ lv_month } ' |  .
        " create a statement object
        l_stmt_ref = go_db->create_statement( tab_name_for_trace = gc_tablename ).
        DATA(l_res_ref2) = l_stmt_ref->execute_update( l_stmt ).
      CATCH cx_sql_exception INTO go_sqlerr_ref.
        " <fs_data>-msg = <fs_data>-msg && go_sqlerr_ref->sql_message.
        MESSAGE go_sqlerr_ref->sql_message TYPE 'E'.
      CATCH cx_parameter_invalid INTO go_sqlerr_inv.
        "<fs_data>-msg = <fs_data>-msg && go_sqlerr_inv->get_text( ).
        MESSAGE go_sqlerr_inv->get_text( ) TYPE 'E'.
    ENDTRY.
  ENDIF.




  LOOP AT lt_formlines_i ASSIGNING FIELD-SYMBOL(<fs_data>).

    "插入数据
    TRY.
        DATA: lv_id(32) TYPE c.
        lv_id = cl_uuid_factory=>create_system_uuid( )->create_uuid_c32( ).
        "  create the query string

        l_stmt = |INSERT INTO { gc_tablename } VALUES(| &&
                       |'{ lv_id }',| &&
                       |'{ lv_year }',| &&
                       |'{ lv_month }',| &&
                       |'{ <fs_data>-linenr }',| &&  "表格部分
                       |'{ <fs_data>-linesec }',| &&   "表格部分
                       |'{ <fs_data>-linelev }',| &&  "抵销编号
                       |'{ <fs_data>-linetype }',| &&  "表格行类型
                       |'{ <fs_data>-linetext }',| &&  "行描述
                       |'{ <fs_data>-linenrext }',| &&  "顺序编号
                       |'{ <fs_data>-ergsl }',| &&  "财务报表项目
                       |'{ <fs_data>-bsum }',| &&  " 货币金额
                       |'{ <fs_data>-vsum }',| &&  "比较金额
                       |'{ <fs_data>-saldo }',| &&  "差额
                       |'{ <fs_data>-waers }')|.  "货币码

        "     |TO_DATE('{ <fs_data>-gltrp }','YYYYMMDD'),| &&
        " create a statement object
        l_stmt_ref = go_db->create_statement( tab_name_for_trace = gc_tablename ).
        DATA(l_res_ref3) = l_stmt_ref->execute_update( l_stmt ).
      CATCH cx_sql_exception INTO go_sqlerr_ref.
        " <fs_data>-msg = <fs_data>-msg && go_sqlerr_ref->sql_message.
        MESSAGE go_sqlerr_ref->sql_message TYPE 'E'.
      CATCH cx_parameter_invalid INTO go_sqlerr_inv.
        "<fs_data>-msg = <fs_data>-msg && go_sqlerr_inv->get_text( ).
        MESSAGE go_sqlerr_inv->get_text( ) TYPE 'E'.
    ENDTRY.
  ENDLOOP.
  MESSAGE 'ZFIR075B 利润表数据同步完毕' TYPE 'S'.


ENDFORM.


FORM get_data3.


  " 设定SALV运行模式
  cl_salv_bs_runtime_info=>set(
    EXPORTING
      display  = abap_false  "不显示
      metadata = abap_false
      data     = abap_true
  ).


  RANGES:r_monat FOR rfsdo-bilabmon.
  r_monat-sign = 'I'.
  r_monat-option = 'BT'.
  r_monat-low = p_month.
  r_monat-high = p_month.
  APPEND r_monat.

  RANGES:r_monatc FOR rfsdo-bilabmon.
  r_monatc-sign = 'I'.
  r_monatc-option = 'BT'.
  r_monatc-low = '1'.
  r_monatc-high = sy-datum+4(2).
  APPEND r_monatc.

  RANGES:r_belnr FOR idcn_3rff4adjdoc-belnr.
  r_belnr-sign = 'I'.
  r_belnr-option = 'CP'.
  r_belnr-low = '*'.
  " r_belnr-high = '*'.
  APPEND r_belnr.


  DATA(lv_zcash) = 'X'.
  EXPORT lv_zcash = lv_zcash TO MEMORY ID 'ZCASH'.

  DATA:lv_adjust  TYPE string.
  DATA:lv_padjust  TYPE string.

  SELECT *
  FROM idcn_3rff4adjdoc
  INTO TABLE @DATA(lt_idcn_3rff4adjdoc1)
  WHERE gjahr = @p_year
  AND monat = @p_month.

  SELECT *
  FROM idcn_3rff4adjdoc
  INTO TABLE @DATA(lt_idcn_3rff4adjdoc2)
  WHERE gjahr = @p_year
  AND monat BETWEEN '1' AND  @p_month.


  IF  lt_idcn_3rff4adjdoc1 IS NOT INITIAL.
    lv_adjust = 'X'.
  ELSE.
    lv_adjust = ''.
  ENDIF.

  IF  lt_idcn_3rff4adjdoc2 IS NOT INITIAL.
    lv_padjust = 'X'.
  ELSE.
    lv_padjust = ''.
  ENDIF.

  SUBMIT j_3rfform4
  WITH so_bukrs-low = '1100'
  WITH p_vers = '1001'
  WITH bupej = p_year
  WITH monat  IN r_monat
  WITH bupejc = p_year
  WITH monatc IN r_monatc

  WITH p_histrt = 'X'"使用历史比率
*  WITH adjust = 'X' "包括调整项目
*  WITH padjust = 'X'
  WITH adjust = lv_adjust
  WITH padjust = lv_padjust
  WITH adj_doc  IN r_belnr
  WITH padj_doc  IN r_belnr
  AND RETURN.

*
*  TRY.
*      "取得运行数据
*      cl_salv_bs_runtime_info=>get_data_ref(
*            IMPORTING
*              r_data = go_data
*      ).
*
*
*
**   数据赋值
*      ASSIGN  go_data->* TO <git_outtab3>.
*
*
*      LOOP AT <git_outtab3> ASSIGNING FIELD-SYMBOL(<fs3>).
*        APPEND <fs3> TO gt_itab3 .
*      ENDLOOP.


  "IMPORT gt_xml_interface TO lt_xml_interface FROM MEMORY ID 'CASH_FLOW_XML'.
  IMPORT gt_output_list TO gt_output_list FROM MEMORY ID 'cash_out_list'.

  DATA: lv_number    TYPE p DECIMALS 2.
  " LOOP AT gt_itab3  ASSIGNING FIELD-SYMBOL(<fs_itab3>)."负号从后面移到前面
  LOOP AT gt_output_list  ASSIGNING FIELD-SYMBOL(<fs_itab3>)."负号从后面移到前面
    REPLACE ALL OCCURRENCES OF ',' IN  <fs_itab3>-amount_total WITH ''.
    REPLACE ALL OCCURRENCES OF ',' IN  <fs_itab3>-amount_prev WITH ''.
    lv_number =  <fs_itab3>-amount_total.
    <fs_itab3>-amount_total = |{ lv_number }|.
    lv_number =  <fs_itab3>-amount_prev.
    <fs_itab3>-amount_prev = |{ lv_number }|.
  ENDLOOP.

*    CATCH cx_salv_bs_sc_runtime_info.
*  ENDTRY.
*  CALL METHOD cl_salv_bs_runtime_info=>clear_all.


ENDFORM.


FORM frm_save3 .


  TYPES: BEGIN OF ty_db,
           id TYPE string,
         END OF ty_db.

  DATA:lt_db TYPE TABLE OF ty_db.
  " DATA:lt_db TYPE TABLE OF zfis016.
  gc_tablename = 'ZFIR075C'.
  DATA go_data2 TYPE REF TO data.



  DATA(lv_year) = p_year.
  DATA(lv_month) = p_month.

  CLEAR:lt_db[].
  "先获取对方数据
  TRY.
      go_db = cl_sql_connection=>get_connection( 'RPDB' ).

      " create the query string
      DATA(l_stmt) = |SELECT  ID  FROM { gc_tablename }  |.
      " create a statement object
      DATA(l_stmt_ref) = go_db->create_statement( tab_name_for_trace = gc_tablename ).
      DATA(l_res_ref) = l_stmt_ref->execute_query( l_stmt ).

      GET REFERENCE OF lt_db INTO go_data2.
      " set output table
      l_res_ref->set_param_table( go_data2 ).

      " get the complete result set
      DATA(l_row_cnt) = l_res_ref->next_package( ).

    CATCH cx_sql_exception INTO go_sqlerr_ref.
      MESSAGE go_sqlerr_ref->sql_message TYPE 'E'.
  ENDTRY.

  IF lt_db[] IS NOT INITIAL."删除数据
    TRY.
        l_stmt  = |DELETE FROM { gc_tablename }  WHERE YEAR =  '{ lv_year } ' AND MONTH =  '{ lv_month } ' |  .
        " create a statement object
        l_stmt_ref = go_db->create_statement( tab_name_for_trace = gc_tablename ).
        DATA(l_res_ref2) = l_stmt_ref->execute_update( l_stmt ).
      CATCH cx_sql_exception INTO go_sqlerr_ref.
        " <fs_data>-msg = <fs_data>-msg && go_sqlerr_ref->sql_message.
        MESSAGE go_sqlerr_ref->sql_message TYPE 'E'.
      CATCH cx_parameter_invalid INTO go_sqlerr_inv.
        "<fs_data>-msg = <fs_data>-msg && go_sqlerr_inv->get_text( ).
        MESSAGE go_sqlerr_inv->get_text( ) TYPE 'E'.
    ENDTRY.
  ENDIF.




  " LOOP AT gt_itab3 ASSIGNING FIELD-SYMBOL(<fs_data3>).
  LOOP AT gt_output_list  ASSIGNING FIELD-SYMBOL(<fs_data3>).
    "插入数据
    TRY.
        DATA: lv_id(32) TYPE c.
        lv_id = cl_uuid_factory=>create_system_uuid( )->create_uuid_c32( ).
        "  create the query string

        l_stmt = |INSERT INTO { gc_tablename } VALUES(| &&
                       |'{ lv_id }',| &&
                       |'{ lv_year }',| &&
                       |'{ lv_month }',| &&
                       |'{ <fs_data3>-text }',| &&  "项目描述
                       |'{ <fs_data3>-strow }',| &&   "代码
                       |'{ <fs_data3>-amount_total }',| &&  "总金额
                       |'{ <fs_data3>-amount_prev }')|.  "比较金额

        "     |TO_DATE('{ <fs_data>-gltrp }','YYYYMMDD'),| &&
        " create a statement object
        l_stmt_ref = go_db->create_statement( tab_name_for_trace = gc_tablename ).
        DATA(l_res_ref3) = l_stmt_ref->execute_update( l_stmt ).
      CATCH cx_sql_exception INTO go_sqlerr_ref.
        " <fs_data>-msg = <fs_data>-msg && go_sqlerr_ref->sql_message.
        MESSAGE go_sqlerr_ref->sql_message TYPE 'E'.
      CATCH cx_parameter_invalid INTO go_sqlerr_inv.
        "<fs_data>-msg = <fs_data>-msg && go_sqlerr_inv->get_text( ).
        MESSAGE go_sqlerr_inv->get_text( ) TYPE 'E'.
    ENDTRY.
  ENDLOOP.
  MESSAGE 'ZFIR075C 现金流量表数据同步完毕' TYPE 'S'.


ENDFORM.





FORM get_data4.

  "	每月实际（销/管/研）费用发生数据
*  SELECT ryear,racct,rbukrs,rcntr,rfarea,hslvt,hsl01,hsl02,hsl03,hsl04,hsl05,hsl06
*        ,hsl07,hsl08,hsl09,hsl10,hsl11,hsl12
*  FROM faglflext AS a
*  INTO TABLE @lt_faglflext1
*  WHERE rbukrs = '1100'
*  AND ryear = @sy-datum(4)
*  AND  rrcty = '0'
*  AND rfarea IN ( '1000' ,'2000','3000' ).


  SELECT ryear,racct,rbukrs,rcntr,rfarea,SUM( hslvt ),SUM( hsl01 ),SUM( hsl02 ),SUM( hsl03 ),
    SUM( hsl04 ),SUM( hsl05 ),SUM( hsl06 ),SUM( hsl07 ),SUM( hsl08 ),SUM( hsl09 ),
    SUM( hsl10 ),SUM( hsl11 ),SUM( hsl12 )
  FROM faglflext AS a
  INTO TABLE @lt_faglflext1
  WHERE rbukrs = '1100'
  AND ryear = @sy-datum(4)
  AND  rrcty = '0'
  AND rfarea IN ( '1000' ,'2000','3000' )
  GROUP BY ryear,racct,rbukrs,rcntr,rfarea.


  "每月实际财务费用发生数据
*  SELECT ryear,racct,rbukrs,rcntr,rfarea,hslvt,hsl01,hsl02,hsl03,hsl04,hsl05,hsl06
*        ,hsl07,hsl08,hsl09,hsl10,hsl11,hsl12
*  FROM faglflext AS a
*  INTO TABLE @lt_faglflext2
*"  FOR ALL ENTRIES IN @gt_data
*  WHERE rbukrs = '1100'
*  AND ryear = @sy-datum(4)
*  AND  rrcty = '0'
*  AND  racct  LIKE '6603%'.

  SELECT ryear,racct,rbukrs,rcntr,rfarea,SUM( hslvt ),SUM( hsl01 ),SUM( hsl02 ),SUM( hsl03 ),
    SUM( hsl04 ),SUM( hsl05 ),SUM( hsl06 ),SUM( hsl07 ),SUM( hsl08 ),SUM( hsl09 ),
    SUM( hsl10 ),SUM( hsl11 ),SUM( hsl12 )
  FROM faglflext AS a
  INTO TABLE @lt_faglflext2
  WHERE rbukrs = '1100'
  AND ryear = @sy-datum(4)
  AND  rrcty = '0'
  AND  racct  LIKE '6603%'
  GROUP BY ryear,racct,rbukrs,rcntr,rfarea.



  "汇总到lt_faglflext1
  lt_faglflext1 = CORRESPONDING #(  BASE ( lt_faglflext1 ) lt_faglflext2 ).


  "科目描述TXT50
  SELECT *
   FROM skat AS a
   INTO TABLE @DATA(lt_skat)
   FOR ALL ENTRIES IN @lt_faglflext1
   WHERE saknr  = @lt_faglflext1-racct.

  "成本中心描述LTEXT
  SELECT *
   FROM cskt AS a
   INTO TABLE @DATA(lt_cskt)
   FOR ALL ENTRIES IN @lt_faglflext1
   WHERE kostl  = @lt_faglflext1-rcntr
   AND spras = '1'.

  "职能范围描述FKBTX
  SELECT *
   FROM tfkbt AS a
   INTO TABLE @DATA(lt_tfkbt)
   FOR ALL ENTRIES IN @lt_faglflext1
   WHERE fkber  = @lt_faglflext1-rfarea
   AND  spras = '1'.

  DATA: lv_ltext TYPE string.

  LOOP AT lt_faglflext1 ASSIGNING FIELD-SYMBOL(<fs_faglflext>).
    IF  line_exists( lt_skat[   saknr = <fs_faglflext>-racct ] ).
      <fs_faglflext>-txt50 = lt_skat[   saknr = <fs_faglflext>-racct ]-txt50 .
    ENDIF.
    IF  line_exists( lt_cskt[   kostl = <fs_faglflext>-rcntr ] ).
      <fs_faglflext>-ltext = lt_cskt[   kostl = <fs_faglflext>-rcntr ]-ktext .
    ENDIF.

    IF <fs_faglflext>-racct(4) = '6603' .
      <fs_faglflext>-fkbtx =  '财务费用'.
    ELSEIF  line_exists( lt_tfkbt[   fkber = <fs_faglflext>-rfarea ] ).
      <fs_faglflext>-fkbtx = lt_tfkbt[   fkber = <fs_faglflext>-rfarea ]-fkbtx .
    ENDIF.

    lv_ltext = <fs_faglflext>-ltext.
    CONDENSE lv_ltext NO-GAPS.
    REPLACE ALL OCCURRENCES OF ` ` IN lv_ltext WITH ''.
    REPLACE REGEX ' +' IN lv_ltext WITH ` `.
    <fs_faglflext>-ltext = lv_ltext.

    <fs_faglflext>-rcntr = |{ <fs_faglflext>-rcntr ALPHA = OUT }|.
    CALL FUNCTION 'ZFM_FI_GET_CJDW'
      EXPORTING
*       IV_UNAME   =
        iv_kostl   = <fs_faglflext>-rcntr
      IMPORTING
        ev_zzorg   = <fs_faglflext>-cjbm
        ev_zzorg_t = <fs_faglflext>-cjbmms
      EXCEPTIONS
        name_error = 1
        OTHERS     = 2.
    IF sy-subrc <> 0.
* Implement suitable error handling here
    ENDIF.



  ENDLOOP.


ENDFORM.


FORM frm_save4 .


  TYPES: BEGIN OF ty_db,
           id TYPE string,
         END OF ty_db.

  DATA:lt_db TYPE TABLE OF ty_db.
  " DATA:lt_db TYPE TABLE OF zfis016.
  gc_tablename = 'ZFIR075D'.
  DATA go_data2 TYPE REF TO data.


  DATA(lv_year) = sy-datum(4).
  DATA(lv_month) = p_month.

  CLEAR:lt_db[].
  "先获取对方数据
  TRY.
      go_db = cl_sql_connection=>get_connection( 'RPDB' ).

      " create the query string
      DATA(l_stmt) = |SELECT  ID  FROM { gc_tablename }  |.
      " create a statement object
      DATA(l_stmt_ref) = go_db->create_statement( tab_name_for_trace = gc_tablename ).
      DATA(l_res_ref) = l_stmt_ref->execute_query( l_stmt ).

      GET REFERENCE OF lt_db INTO go_data2.
      " set output table
      l_res_ref->set_param_table( go_data2 ).

      " get the complete result set
      DATA(l_row_cnt) = l_res_ref->next_package( ).

    CATCH cx_sql_exception INTO go_sqlerr_ref.
      MESSAGE go_sqlerr_ref->sql_message TYPE 'E'.
  ENDTRY.

  IF lt_db[] IS NOT INITIAL."删除数据
    TRY.
        l_stmt  = |DELETE FROM { gc_tablename }  WHERE RYEAR =  '{ lv_year } ' |  .
        " create a statement object
        l_stmt_ref = go_db->create_statement( tab_name_for_trace = gc_tablename ).
        DATA(l_res_ref2) = l_stmt_ref->execute_update( l_stmt ).
      CATCH cx_sql_exception INTO go_sqlerr_ref.
        " <fs_data>-msg = <fs_data>-msg && go_sqlerr_ref->sql_message.
        MESSAGE go_sqlerr_ref->sql_message TYPE 'E'.
      CATCH cx_parameter_invalid INTO go_sqlerr_inv.
        "<fs_data>-msg = <fs_data>-msg && go_sqlerr_inv->get_text( ).
        MESSAGE go_sqlerr_inv->get_text( ) TYPE 'E'.
    ENDTRY.
  ENDIF.


  LOOP AT lt_faglflext1 ASSIGNING FIELD-SYMBOL(<fs_data>).

    <fs_data>-rcntr = |{ <fs_data>-rcntr ALPHA = OUT }|.
    "插入数据
    TRY.
        DATA: lv_id(32) TYPE c.
        lv_id = cl_uuid_factory=>create_system_uuid( )->create_uuid_c32( ).
        "  create the query string

        l_stmt = |INSERT INTO { gc_tablename } VALUES(| &&
                       |'{ lv_id }',| &&
                     "  |'{ lv_year }',| &&
                     "  |'{ lv_month }',| &&
                       |'{ <fs_data>-ryear  }',| &&
                       |'{ <fs_data>-racct }',| &&
                       |'{ <fs_data>-rbukrs }',| &&
                       |'{ <fs_data>-rcntr  }',| &&
                       |'{ <fs_data>-rfarea }',| &&
                       |'{ <fs_data>-hslvt }',| &&
                       |'{ <fs_data>-hsl01 }',| &&
                       |'{ <fs_data>-hsl02 }',| &&
                       |'{ <fs_data>-hsl03 }',| &&
                       |'{ <fs_data>-hsl04 }',| &&
                       |'{ <fs_data>-hsl05 }',| &&
                       |'{ <fs_data>-hsl06 }',| &&
                       |'{ <fs_data>-hsl07 }',| &&
                       |'{ <fs_data>-hsl08 }',| &&
                       |'{ <fs_data>-hsl09 }',| &&
                       |'{ <fs_data>-hsl10 }',| &&
                       |'{ <fs_data>-hsl11 }',| &&
                       |'{ <fs_data>-hsl12 }',| &&
                       |'{ <fs_data>-txt50 }',| &&
                       |'{ <fs_data>-ltext }',| &&
                       |'{ <fs_data>-fkbtx }',| &&
                       |'{ <fs_data>-cjbm }',| &&
                       |'{ <fs_data>-cjbmms }')|.
        "     |TO_DATE('{ <fs_data>-gltrp }','YYYYMMDD'),| &&
        " create a statement object
        l_stmt_ref = go_db->create_statement( tab_name_for_trace = gc_tablename ).
        DATA(l_res_ref3) = l_stmt_ref->execute_update( l_stmt ).
      CATCH cx_sql_exception INTO go_sqlerr_ref.
        " <fs_data>-msg = <fs_data>-msg && go_sqlerr_ref->sql_message.
        MESSAGE go_sqlerr_ref->sql_message TYPE 'E'.
      CATCH cx_parameter_invalid INTO go_sqlerr_inv.
        "<fs_data>-msg = <fs_data>-msg && go_sqlerr_inv->get_text( ).
        MESSAGE go_sqlerr_inv->get_text( ) TYPE 'E'.
    ENDTRY.
  ENDLOOP.
  MESSAGE 'ZFIR075D 费用报表数据同步完毕' TYPE 'S'.


ENDFORM.
